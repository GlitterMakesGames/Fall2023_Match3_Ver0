using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BoardScript : MonoBehaviour
{
    public int board_width;
    public int board_height;
    public GameObject tilePrefab;
    [SerializeField] private TileScript[,] allTiles;

    void Start()
    {
        allTiles = new TileScript[board_width, board_height];
    }

    void SetUp()
    {
        for(int x = 0; x < board_width; x++)
        {
            for(int y = 0; y < board_height; x++)
            {
                Vector2 tempPosition = new Vector2(x,y);
                GameObject _bgTile = Instantiate(tilePrefab, tempPosition, Quaternion.Identity) as GameObject;
            }
        }
    }
}
